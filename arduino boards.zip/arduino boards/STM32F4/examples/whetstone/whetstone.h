int whetstone(int);

void blinks(void);

